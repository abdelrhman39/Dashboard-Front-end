Make sure to add the .icon-outline class to your outline svg icons when using them in your web project:

<svg class="icon icon-outline"><use href="#icon-name" xlink:href="#icon-name"/></svg>

If you have organized icons in a Nucleo project, you can copy the svg code directly from the project page. You can read more about that on our Documentation page:
https://nucleoapp.com/docs/organizing-icons#why-projects